<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="buildings" tilewidth="24" tileheight="24" tilecount="376" columns="47">
 <image source="../Textures/buildings.png" width="1136" height="197"/>
</tileset>
