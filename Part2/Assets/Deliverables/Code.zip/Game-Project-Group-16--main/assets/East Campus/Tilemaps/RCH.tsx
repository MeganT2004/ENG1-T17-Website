<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="RCH" tilewidth="24" tileheight="24" tilecount="120" columns="12">
 <image source="../Textures/RCH.png" width="288" height="240"/>
</tileset>
