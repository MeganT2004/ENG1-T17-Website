<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="buildings2" tilewidth="24" tileheight="24" tilecount="975" columns="75">
 <image source="../Textures/buildings2.png" width="1801" height="312"/>
</tileset>
