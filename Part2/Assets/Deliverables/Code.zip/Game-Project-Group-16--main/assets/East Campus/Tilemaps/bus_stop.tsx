<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="bus_stop" tilewidth="24" tileheight="24" tilecount="49" columns="7">
 <image source="../Textures/bus_stop.png" width="180" height="180"/>
</tileset>
