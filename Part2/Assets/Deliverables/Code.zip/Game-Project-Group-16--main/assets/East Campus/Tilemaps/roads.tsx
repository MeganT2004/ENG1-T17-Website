<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="roads" tilewidth="24" tileheight="24" tilecount="768" columns="32">
 <image source="../Textures/roads.jpg" width="768" height="576"/>
</tileset>
