<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="library" tilewidth="24" tileheight="24" tilecount="1248" columns="104">
 <image source="../Textures/library.png" width="2500" height="310"/>
</tileset>
