<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="roads2" tilewidth="24" tileheight="24" tilecount="512" columns="32">
 <image source="../Textures/roads2.jpg" width="768" height="384"/>
</tileset>
